# import the bull riders dataset
# two questions to answer

# 1 . Is the mean age of riders in 2012 different than 30
# null hypothesis - u = 30 , alt hyp  - u != 30

# get the age variable by substracting born year from 2012
age <- 2012 - bulls$YearBorn

# check for normality assumption to use the one sample t test
# not much skewness shown and seems almost normal
hist(age)
# reject the null hypothesis
# two tailed test
t.test(age,mu = 30)



# 2 . Is the mean age greater than 30
# null - u <= 30 , alt hyp u > 30
t.test(age,mu=30,alternative = 'greater')

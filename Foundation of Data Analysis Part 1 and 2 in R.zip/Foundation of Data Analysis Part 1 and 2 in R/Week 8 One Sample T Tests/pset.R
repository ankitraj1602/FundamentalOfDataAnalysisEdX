bag <- c(29.4,29.0,28.4,28.8,28.9,29.3,28.5,28.2 )
mean(bag)
sd(bag)

t.test(bag,mu=28.5)

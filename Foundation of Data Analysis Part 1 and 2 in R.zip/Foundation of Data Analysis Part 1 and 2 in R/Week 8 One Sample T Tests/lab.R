# Primary Research Question

# Do professional bull riders stay on their bulls 50% of the time? 
#  Test the hypothesis that the mean ride percentage is 0.500 in 2014, 
# using riders with at least 5 events in 2014. 

riders_events <- bulls[bulls$Events14 >= 5,]

# the histogram seems normal, so one sample t test assumption verified
hist(riders_events$RidePer14)

mean(riders_events$RidePer14)# 0.33456
sd(riders_events$RidePer14) # 0.10657

t.test(riders_events$RidePer14,mu = 0.5)

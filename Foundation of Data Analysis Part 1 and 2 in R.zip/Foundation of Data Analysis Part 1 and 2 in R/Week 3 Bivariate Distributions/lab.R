# interested in earning , ride percentage and cup points of 2012
riders12 <- bullriders[bullriders$Events12 > 0,]
hist(riders12$Earnings12,10) # skewed positive
hist(riders12$CupPoints12,10) # skewed positive
hist(riders12$RidePer12,10) # skewed positive
fivenum(riders12$Earnings12) 
fivenum(riders12$CupPoints12)
fivenum(riders12$RidePer12)

plot(riders12$CupPoints12,riders12$Earnings12,xlab='Cup Points 2012',
     ylab = 'Earnings 2012',main = 'Cup Points vs Earnings 2012')
plot(riders12$RidePer12,riders12$Earnings12,xlab='Ride Percentage 2012',
     ylab = 'Earnings 2012',main = 'Ride % vs Earnings 2012')

# both show linear relationships
abline(lm(riders12$Earnings12 ~ riders12$CupPoints12))
abline(lm(riders12$Earnings12 ~ riders12$RidePer12))

cor(riders12$CupPoints12,riders12$Earnings12) # 0.656
cor(riders12$RidePer12,riders12$Earnings12) # 0.593

# corelational matrix
myvals_lab <- c('Earnings12','RidePer12','CupPoints12');
cor(riders12[,myvals_lab])

# analysing outlier
which(riders12$Earnings12 == max(riders12$Earnings12))

# remove this outlier in new data frame
nooutlier <- riders12[riders12$Earnings12 < max(riders12$Earnings12),]
cor(nooutlier[,myvals_lab])


#################### probelem sets

new_bull <- bullriders[bullriders$Rides14 > 0,]
RidesPerEvent14 <- new_bull$Rides14/new_bull$Events14

hist(RidesPerEvent14,breaks=15)
fivenum(RidesPerEvent14)
min(RidesPerEvent14)

plot(RidesPerEvent14,new_bull$Rank14)
abline(lm(new_bull$Rank14 ~ RidesPerEvent14))
cor(RidesPerEvent14,new_bull$Rank14)


plot(pset$Minutes,pset$Grade)
cor(pset$Minutes,pset$Grade)

pset_nooutlier <- pset[pset$Grade != 92,]
cor(pset_nooutlier$Minutes,pset_nooutlier$Grade)

riders13 <- bullriders[bullriders$Events13>=1,]

# analyze the first variable of interest rides of 8 secs
hist(riders13$Rides13,breaks = 10)
mean(riders13$Rides13) # 18 rides
fivenum(riders13$Rides13) # 0 11 19 25 50
sd(riders13$Rides13) # 12.73

# analyze second variable, number of top 10 ranks
hist(riders13$Top10_13,breaks = 10)
median(riders13$Top10_13) # 6 times
fivenum(riders13$Top10_13) # 0  2  6  8 14
sd(riders13$Top10_13) # 4.03

plot(riders13$Rides13,riders13$Top10_13,xlab = 'Rides in 2013',
     ylab = 'Top 10 in 2013')
abline(lm(riders13$Top10_13 ~ riders13$Rides13))
cor(riders13$Rides13,riders13$Top10_13) # 0.91

# creating a corelation matrix
myvals <- c('Rides13','Top10_13')
cor(riders13[,myvals])

which(riders13$Top10_13==2 & riders13$Rides13==22)

# check the assumption of linearity using a scatterplot for two variables
# plot gives the scatterplot for numerical variables
# using pch = 15 changes the data points color to black
plot(bullriders$YearsPro,bullriders$BuckOuts14,xlab = 'Years Pro',
     ylab = 'buck outs')
# the graph does not really clear the relationship between these two variables
# in these cases the r value is expected to be 0.

# we can now fit a linear model to this data, a line of best fit
# for this kind of plot line is pretty flat

# visual for how the line will fit (model for the variables) 
# can be made using abline function
# since we want a linear relationship 
# we us lm function in abline fine

abline(lm(bullriders$BuckOuts14~bullriders$YearsPro))
# notice we have changed the variables direction list
# dependent variable first and independent second
# this simply means we are saying dependent variable buck outs as a
# function of years pro


plot(bullriders$Events14,bullriders$BuckOuts14,xlab = 'Events Participated',
     ylab = 'buck outs')
# the above sccatterplot shows a clear linear relationship, and if we 
# fit a linear model it will be pretty straight upward line
abline(lm(bullriders$BuckOuts14~bullriders$Events14))


# we can fine corelation coefficient with cor function
cor(bullriders$YearsPro,bullriders$BuckOuts14) # as in plot a flat line,so 0.18
cor(bullriders$Events14,bullriders$BuckOuts14)# as in plot linear line so 0.99

# we can also create a correlation matrix using vectors and dataframe
# this matrix contains the correlations of specified columns

# first create a vector of variables we are interested in
myvars <- c('YearsPro','Events14','BuckOuts14')
# in the cor function, specify the data frame rows and colums
# we use no rows value because we are interested in every data frame row
# in calculation of corelation value
cor(bullriders[,myvars])

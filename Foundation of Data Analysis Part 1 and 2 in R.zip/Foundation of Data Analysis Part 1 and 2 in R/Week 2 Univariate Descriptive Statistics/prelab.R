table(AnimalData$Outcome.Type)

adoptedAnimals <- AnimalData[AnimalData$Outcome.Type == 'Adoption',]
head(adoptedAnimals)

hist(adoptedAnimals$Days.Shelter,main='Adopted Animals',xlab='Days in Shelter'
     ,breaks = 15)

# looking at the histogram, the measure of centre should be median
# measure of spread should be inter quartile range
# because the shape of distribution is very skewed to the right

mean(adoptedAnimals$Days.Shelter) # 29.26
median(adoptedAnimals$Days.Shelter) # 13
sd(adoptedAnimals$Days.Shelter) # 35.71

fivenumbox <- fivenum(adoptedAnimals$Days.Shelter) # 2 8 13 38 211
iqr <- fivenumbox[4] - fivenumbox[2] # 30

# finding outliers in the data
# if we see there were two animals that were in the shelter for more than 200 days

adoptedAnimals[
  which(adoptedAnimals$Days.Shelter == max(adoptedAnimals$Days.Shelter)),] # 211

# z score for this animal
max_z_score <- (211 - 29.26)/35.71


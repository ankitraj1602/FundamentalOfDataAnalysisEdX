adultcatsdogs <- AnimalData[AnimalData$Age.Intake >= 1,]
table(adultcatsdogs$Animal.Type)

cats <- AnimalData[AnimalData$Animal.Type == 'Cat',]
adultcats <- cats[cats$Age.Intake >= 1,]
dogs <-AnimalData[AnimalData$Animal.Type == 'Dog',]
adultdogs <- dogs[dogs$Age.Intake >= 1,]


hist(adultcats$Weight,breaks = 10)
# looking at cats weight histogram, mean and sd are measures of centre and spread

hist(adultdogs$Weight,breaks = 15)
# centre could be median and spread to be IQR , looking at the data

mean(adultcats$Weight) # 8.60
sd(adultcats$Weight) # 1.91
median(adultcats$Weight)

# z score for a 13 pound cat is :  2.303
1-pnorm(2.303) # proportion for cats more than 13 pounds

median(adultdogs$Weight) # 35.25 
fivenum(adultdogs$Weight) # 3.30 13.50 35.25 54 131
# spread measure for dogs are 40.50
# the 13 pound dog is in the 1st quaurtile

dogsweight <- adultdogs$Weight
dogsweight[dogsweight == 13]




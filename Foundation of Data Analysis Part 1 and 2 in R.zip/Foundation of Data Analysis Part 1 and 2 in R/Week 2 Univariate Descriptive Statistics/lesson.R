
# import bike data for this lesson, because i didn't find the used file

# head function provides a quick snapshot of data frame with 6 rows
head(bikedata)

# use plot function gives a bar chart for a categorical variable
# main , and ylab and xlab can be used to assign labels to top,left and right axis
# this function for my data set is not working for some reason , but it is simple
plot(bikedata$gender)

# histogram for the quantitative variable can be seen using hist function
# we can use breaks = 12 or whatever to decide how many bins we want in graph 
hist(bikedata$distance,main='Distance covered',xlab='Students',ylab='Frequency'
     ,breaks = 10)

#creating histograms by groups
# suppose we wan't to create separate histograms for distance 
# travelled by males and females

# first create male and female distance travelled vector objects
males <- bikedata$distance[bikedata$gender=='M']
females <- bikedata$distance[bikedata$gender=='F']

# then create the histograms for the vectors
hist(males,main='Distance travlled by males',xlab = 'Males',breaks = 10)
hist(females,main='Distance travlled by females',xlab = 'females',breaks = 10)

# which function on data frame gives the row number which satifies a conditon
max(females)
# we want the row for max distance travelled by female
# returns the row number for this female i.e 103
which(bikedata$distance == max(females))
# see the data frame for row 103
bikedata[103,]

# calculating the measures of centre and spread
mean(bikedata$distance)
median(bikedata$distance)

sd(bikedata$distance) # gives standard deviation
fivenum(bikedata$distance) # five number summary(used to made box and whisker)

# pnorm(z score val) gives the proportion of values that are less than this
# using th concept of empirical rule in normal distribution

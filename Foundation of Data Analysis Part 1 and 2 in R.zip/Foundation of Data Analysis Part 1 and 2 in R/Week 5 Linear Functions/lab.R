table(wr$Event)
wrwomenmile<- wr[wr$Event == 'Womens Mile',]
mmiles <- wr[wr$Event == 'Mens Mile',]

mcoly <- mmiles$Year - min(mmiles$Year)
wcoly <- wrwomenmile$Year - min(wrwomenmile$Year)

plot(mcoly,mmiles$Record,pch = 16)
plot(wcoly,wrwomenmile$Year,pch = 16)

mmmodel <- lm (mmiles$Record ~ mcoly)
summary(mmmodel)
abline(mmmodel)

wmmodel <- lm (wrwomenmile$Record ~ wcoly)
summary(wmmodel)
plot(wcoly,wrwomenmile$Year,pch = 16)
abline(wmmodel)

# mens equation


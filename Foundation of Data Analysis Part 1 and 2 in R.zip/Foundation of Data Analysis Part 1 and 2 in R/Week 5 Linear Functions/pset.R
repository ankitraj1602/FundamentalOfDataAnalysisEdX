pv <- wr[wr$Event =='Mens Polevault',]
pv70 <- pv[pv$Year >= 1970,]

max(pv70$Record)
plot(pv$Year,pv$Record)
pm <- lm(pv70$Record ~ pv70$Year)
abline(pm)
summary(pm)

wr800 <- wr[wr$Event == 'Mens 800m',]

plot(wr800$Year,wr800$Record0)

# linFit function does not work because its in the package
# so we can simply use lm function
# assigning a new object
lmodel <- lm(wr800$Record~wr800$Year)
abline(lmodel)

# call summary function to see the intercept and r square value
# slope value is below the intercept value
summary(lmodel)

# this time we created year values from '0'
# this way the y intercept makes sense to us
# earlier it was giving a value of 345 odd
# now the y intercept means the predicted value of record 
# time when year is 1912
newcol <- wr800$Year -  min(wr800$Year)
plot(newcol,wr800$Record,xlab = 'Records from year 1912',ylab ='Time'
     ,main = 'Mens 800m record time from 1912-2012')
lmodel2 <- lm(wr800$Record ~ newcol)
abline(lmodel2)
summary(lmodel2)

table(wr$Event)

wr100 <- wr[wr$Event == 'Mens 100m',]
wrwomenmile<- wr[wr$Event == 'Womens Mile',]

mensput <- wr[wr$Event == 'Mens Shotput',]
mcol <- mensput$Year - min(mensput$Year)
plot(mcol,mensput$Record)
mpmodel <- lm(mensput$Record ~ mcol)
abline(mpmodel)
summary(mpmodel)

wput <- wr[wr$Event == 'Womens Shotput',]
wcol <- wput$Year - min(wput$Year)
plot(wcol,wput$Record,pch = 16)
wpmodel <- lm(wput$Record ~ wcol)
abline(wpmodel)
summary(wpmodel)




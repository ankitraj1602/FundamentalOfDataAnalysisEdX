gbr <- world[world$Country.Code == 'GBR',]
gbr2000 <- gbr[gbr$year >= 2000 & gbr$year < 2010,]

time0 <- gbr2000$year - 2000
cars <- gbr2000$motor.vehicles

plot(time0,cars,pch = 16)
# we cannot use the exponential model directly because expFit function only
# exists in the SDS package , which we cannot access now

# now we use the concept of log to plot logy values to find exponetial model
logcars <- log(cars,10)
plot(time0,logcars,pch = 16)
logmodel <- lm(logcars ~ time0)
summary(logmodel) # logy = 0.0080982x + 7.4457841
# when we solve for y in this equation 
# we roughly get y = 1.01882^x(27911559.341755)
# in the video we got the value 27911561 to be precise


# created a function for predicting
predictYExpo <- function(x) {
  y <- (1.01882 ** x) * 27911562
  return (y)
}

predictYExpo(12)
# cannot figure out the logistic regression

# now i have installed the sds foundations package
# so we can now use the functions in the sds package
# but we will try to find general solutions as well
linFit(time0,cars) # gives linear model
expFit(time0,cars) # gives exponential model
logisticFit(time0,cars) # gives logistic model
expFitPred(time0,cars,12) # prediction for exponential fit model based on x value
logisticFitPred(time0,cars,12) # prediction for logistic fit model based on x value
tripleFit(time0,cars) # imposes all three models on a plot

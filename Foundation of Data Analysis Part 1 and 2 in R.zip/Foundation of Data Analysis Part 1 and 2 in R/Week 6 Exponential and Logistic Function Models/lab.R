denmark <- world[world$Country.Code == 'DNK',]
dnk1990 <- denmark[denmark$year>=1990,]

dnk_years <- dnk1990$year - min(dnk1990$year)
dnk_int_users<- dnk1990$internet.users

plot(dnk_years,dnk_int_users)

linFit(dnk_years,dnk_int_users)
expFit(dnk_years,dnk_int_users)
logisticFit(dnk_years,dnk_int_users)

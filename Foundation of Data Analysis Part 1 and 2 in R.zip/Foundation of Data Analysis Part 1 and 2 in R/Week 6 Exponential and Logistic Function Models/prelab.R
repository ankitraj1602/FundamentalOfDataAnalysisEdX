us <- world[world$Country.Code == 'USA',]
usdecade <- us[us$year >= 1990 & us$year <= 1999,]

years <- usdecade$year - min(usdecade$year)
int_users <- usdecade$internet.users

graph_val <- plot(years,int_users,main = 'Internet users in USA since 1990 to 1999',
                  xlab = 'Years',ylab = 'Internet Users',pch = 16)

linFit(years,int_users)
expFit(years,int_users)
logisticFit(years,int_users)

expFitPred(years,int_users,16)
logisticFitPred(years,int_users,16)

brazil <- world[world$Country.Code == 'BRA',]
bra1995 <- brazil[brazil$year >= 1995,]
bra1995$yearsSince1995 <- bra1995$year - 1995
bra1995$milUsers <- bra1995$mobile.users / 1000000

plot(bra1995$yearsSince1995,bra1995$milUsers)
linFit(bra1995$yearsSince1995,bra1995$milUsers)
expFit(bra1995$yearsSince1995,bra1995$milUsers)
logisticFit(bra1995$yearsSince1995,bra1995$milUsers)
logisticFitPred(bra1995$yearsSince1995,bra1995$milUsers,30)

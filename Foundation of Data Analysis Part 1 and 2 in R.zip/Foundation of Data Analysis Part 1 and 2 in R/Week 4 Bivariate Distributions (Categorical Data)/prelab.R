acl30 <- acl[acl$Age >= 30,]
table(acl30$Gender)

gtable <- table(acl30$Genre) # genre table
gtable
prop.table(gtable)
barplot(prop.table(gtable),xlab = 'Genre',ylab = 'Counts'
        ,main = 'Distribution of genre')

ctable <- table(acl30$Gender,acl30$Genre)
ctable

prop.table(ctable,1)
barplot(prop.table(ctable,1),xlab = 'Genre',ylab = 'Counts',beside = T
        ,main = 'Distribution of artists genre by gender',legend = T)

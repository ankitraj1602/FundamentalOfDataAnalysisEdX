males <- acl[acl$Gender == 'M',]
tabgramy <- table(males$Grammy)
tabgramy
prop.table(tabgramy)
barplot(tabgramy)

genres <- table(males$Genre)
genres
prop.table(genres)
barplot(genres)

ctable <- table(males$Genre,males$Grammy)
ctable
prop.table(ctable,1)
barplot(prop.table(ctable,1),xlab = 'Grammy Winners',ylab='Counts',
        main = 'Distribution of grammy winners with Genre',beside = T
        )

# table function gives a table object
# we are assigning the object to a gtab variable
gtab <- table(acl$Grammy)

prop.table(gtab) #gives the proportions of the table values

# we can make a contingency table by providing to 2 columns in table function
# the second column's values will acquire column places
# the first column values will acquire the row places
gtab2 <- table(acl$Grammy,acl$Gender)
gtab2

# now we can use the same prop.table function to see proportion in contingency table
# by default it just creates proportions on the basis of total observations
prop.table(gtab2)

# we can provide the second argument as 1 and 2
# 1 will create proportions conditional to rows
# 2 will create proportions conditional to columns
prop.table(gtab2,1)
prop.table(gtab2,2)


# we can use barplot function to give a bar chart of categorical variables
# we can provide a table of counts as a argument
barplot(gtab,xlab = 'Gender',ylab ='Counts',main='Gender Count of Grammy Winners')

# we can also provide the contingency table as an argument to the barplot
# here we can use legend = T, to let 'R' give as what color means what
# by default the values are stacked on top of each other
barplot(gtab2, xlab = 'Genders',ylab='Count',legend = T,
        main='Winners of grammy by gender')

# to make the values stand side by side and not stacked , use beside keyword
barplot(gtab2, xlab = 'Genders',ylab='Count',legend = T,
        main='Winners of grammy by gender',beside = T)

# we can also use prop.table function inside barplot
# this will create a frequency count of the conditional values
# according to the prop.table 
barplot(prop.table(gtab2,1), xlab = 'Genders',ylab='Count',
        main='Winners of grammy by gender',legend = T)
# now pay attention to how we are using prop.table to explain the graph
gtab2

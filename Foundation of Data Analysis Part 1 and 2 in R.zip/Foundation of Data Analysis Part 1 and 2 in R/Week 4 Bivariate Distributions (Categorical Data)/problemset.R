table(acl$Facebook.100k == 1)
pops <- acl[acl$Facebook.100k == 1,]
table(pops$Age.Group)


# contingency table for age group and over 100k followers
ctable <- table(acl$Facebook.100k,acl$Age.Group)
ctable
prop.table(ctable,2)

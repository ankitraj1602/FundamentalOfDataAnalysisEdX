#  Primary Research Question
# How many letters long is the typical UT student’s name?  
# How does our estimate change as we increase the size of our sample?

mean(students$name_letters)  # 5.971
sd(students$name_letters) # 1.495
hist(students$name_letters)

# create a 1000 samples each of size 5
my_sm_5 <- rep(NA,1000)
for(i in 1:1000){
  sample_5 = sample(students$name_letters,5)
  my_sm_5[i] <- mean(sample_5)
}

hist(my_sm_5,xlim = c(2,10)) # almost normal
mean(my_sm_5) #5.989
sd(my_sm_5) # 0.657


# create a 1000 samples each of size 10
my_sm_10 <- rep(NA,1000)
for(i in 1:1000){
  sample_10 = sample(students$name_letters,10)
  my_sm_10[i] <- mean(sample_10)
}

hist(my_sm_10) # more normal than that of size 5 samples
mean(my_sm_10) #5.963
sd(my_sm_10) # 0.453


# create a 1000 samples each of size 25
my_sm_25 <- rep(NA,1000)
for(i in 1:1000){
  sample_25 = sample(students$name_letters,25)
  my_sm_25[i] <- mean(sample_25)
}

# xlim function is used to set limit on the X AXIS
hist(my_sm_25,xlim = c(2,10)) # more normal than that of size 10 samples
mean(my_sm_25) #5.965
sd(my_sm_25) # 0.287

mean(students$age) # 19.26
sd(students$age) # 2.27
hist(students$age) # right skewed

# create a random sample from the age variable using sample function
random_sample <- sample(students$age,30)

# rep function is used to assign initial members and size of vectors
my_sample <- rep(NA,1000)
# create a for loop and collect 1000 random sample means of size 10
for(i in 1:1000){
  ex_sample = sample(students$age,30)
  my_sample[i] = mean(ex_sample)
}

hist(my_sample) # almost normal, centered around population mean of 19.26
sd(my_sample) # 0.405
sd(students$age)/sqrt(30) # 0.414
# the sd is also almost same, credit to the CENTRAL LIMIT THEOROM

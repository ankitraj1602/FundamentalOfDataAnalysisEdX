# Primary Research Question

# What percentage of the time are college students happy?  
# How does our estimate of the true mean change as sample size increases?
hist(students$happy) # left skewed
mean(students$happy)# 78.03
sd(students$happy) #16.30913.3
median(students$happy)#80

# now we draw 1000 samples of size 6 , 15 , 25
happy_5 <- rep(NA,1000)
for(i in 1 : 1000){
  samp <- sample(students$happy,5)
  happy_5[i] <- mean(samp)
}

hist(happy_5,xlim = c(40,100)) # kind of left skewed a little
mean(happy_5) #77.78
sd(happy_5) # 7.16


happy_15 <- rep(NA,1000)
for(i in 1 : 1000){
  samp <- sample(students$happy,15)
  happy_15[i] <- mean(samp)
}

hist(happy_15,xlim = c(40,100)) # just a tad left skewed but resembles normal
mean(happy_15) # 77.75
sd(happy_15) # 4.3047


happy_25 <- rep(NA,1000)
for(i in 1 : 1000){
  samp <- sample(students$happy,25)
  happy_25[i] <- mean(samp)
}

hist(happy_25,xlim = c(40,100)) # resembles normal
mean(happy_25) # 78.01
sd(happy_25) # 3.13

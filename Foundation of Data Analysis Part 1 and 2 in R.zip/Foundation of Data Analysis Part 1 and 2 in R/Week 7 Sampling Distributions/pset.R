# On a scale of 1 to 10, how much do UT Austin students like Austin?
#  1. What are the true mean and standard deviation for our population of UT Austin students?
#  2. What should the sampling distribution of the mean look like, as predicted by 
# the Central Limit Theorem?
#  3. How do our simulated values compare to these predicted values?

hist(students$austin)
mean(students$austin)
sd(students$austin)


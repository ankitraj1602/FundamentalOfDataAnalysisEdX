# for this lab import data set bike data from downloads

bike
# Find the number of students in the dataset
table(bike$student)

# Pull out student data into a new dataframe
student <-bike[bike$student==1,]

# Find how often the students ride, using the new dataframe
table(student$cyc_freq)

# Create a vector for the distance variable
distance <-student$distance

# Find average distance ridden
mean(distance)


# ansering about the males and females lab question
table(bike$cyc_freq)

daily_riders <- bike[bike$cyc_freq=='Daily',]
table(daily_riders$gender)
mean(daily_riders$age)
males_age_vec <- daily_riders$age[daily_riders$gender == 'M']
females_age_vec <- daily_riders$age[daily_riders$gender == 'F']

mean(males_age_vec)
mean(females_age_vec)

over_30_m <- males_age_vec[males_age_vec >= 30]
length(over_30_m)

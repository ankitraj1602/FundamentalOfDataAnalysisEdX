# some symbol
x <- 9
sqrt(x)

# creating vectors
myvar = c(12,4,45,65,6)
sum(myvar)
length(myvar)
mean(myvar)
median(myvar)
sqrt(myvar)
myvar2 <- myvar * 1.5

# we can use indexing to get a element from vectors, index starts from 1
myvar[2]
myvar[2] <- 14 # we can also change values via indexing

# > < != == can also be used to get results based on logical operations
myvar > 20
# above will just print true false for all items in the vectors

# also these logical comparisions can be used while indexing
myvar[myvar != 4]


# we have imported a data frame object which has details in csv file
# the column names are the variables in the data frame object

mean(Details$id) # '$' used to access the variables in data frame
idvar <- Details$id # assign a vector to details's "id" column

#when we have categorical data, we can use table function to see frequency count
table(Details$profession)


# indexing a data frame

#provide two parameters, for a row and for a column
Details[2,4] # this gives a vector object

# leave one parameter empty to fetch desired rows or columns
Details[4,] # this gives a vector object

table(Details$profession)

# prints the true false for all rows
Details$profession == 'worker'


# when we use logical statements inside indexing, a new data frame 
# object is given :: workers is a data frame
workers  <- Details[Details$profession == 'worker',]


# Below code gives the mails of the workers
#     how it works : first it creates a data frame object, then it gives
#     the email variable or column
workermails <- Details[Details$profession == 'worker',]$email

# but the above code to get the worker emails can be done easily 
#                 without creating a data frame object
workermails <- Details$email[Details$profession == 'worker']
